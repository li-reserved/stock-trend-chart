﻿param([switch]$NoOpen, [switch]$SelfTest)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$script:StockCode = '(?<![0-9.])(?:00|30|60|68|[48][0-9]|92)[0-9]{4}(?:(?=\.(?i:SH|SZ|BJ)\b)|(?![0-9.]))'
$script:CodeTag = '(?:证券代码|股票代码|品种代码|证券编号|股票编号|证券|股票|代码|(?i:SH|SZ|BJ))\s*[:：.]?\s*'
function Get-Codes([string]$Text, [switch]$RequireContext) {
    $Text = $Text.Normalize([Text.NormalizationForm]::FormKC)
    if ($RequireContext) {
        $codes = @(
            [regex]::Matches($Text, ($script:CodeTag + '(' + $script:StockCode + ')')) | ForEach-Object { $_.Groups[1].Value }
            [regex]::Matches($Text, ('\(\s*(' + $script:StockCode + ')\s*\)')) | ForEach-Object { $_.Groups[1].Value }
            [regex]::Matches($Text, ('(?:[\p{IsCJKUnifiedIdeographs}]{2,12}\s*(' + $script:StockCode + ')|(' + $script:StockCode + ')\s*[\p{IsCJKUnifiedIdeographs}]{2,12})')) |
                ForEach-Object { if ($_.Groups[1].Success) { $_.Groups[1].Value } else { $_.Groups[2].Value } }
        )
    } else {
        $codes = @([regex]::Matches($Text, $script:StockCode) | ForEach-Object { $_.Value })
    }
    return @($codes | Sort-Object -Unique)
}

if ($SelfTest) {
    $cases = @(
        @{ text = '通达信V7.68 - 中文在线(３００３６４)'; expected = '300364' },
        @{ text = '同花顺(v9.10.60) - A股技术分析'; expected = '' },
        @{ text = '证券代码：920799'; expected = '920799' },
        @{ text = '通达信 三一重工 600031.SH'; expected = '600031' },
        @{ text = '18.600031 / 成交额 600031.80'; expected = '' },
        @{ text = '中文在线 300364 三一重工 600031'; expected = '300364,600031' }
    )
    foreach ($case in $cases) {
        if ((@(Get-Codes $case.text) -join ',') -ne $case.expected) { throw '代码识别用例失败' }
    }
    if ((@(Get-Codes '600031' -RequireContext).Count -ne 0) -or
        ((@(Get-Codes '中文在线 300364' -RequireContext) -join ',') -ne '300364')) {
        throw '上下文识别用例失败'
    }
    'Stock code recognition tests passed.'
    return
}

Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes, System.Drawing, System.Runtime.WindowsRuntime
Add-Type -ReferencedAssemblies System.Drawing -TypeDefinition @'
using System;
using System.Drawing;
using System.Runtime.InteropServices;

public static class StockWindow {
    [StructLayout(LayoutKind.Sequential)]
    private struct Rect { public int Left, Top, Right, Bottom; }
    [DllImport("user32.dll")] private static extern bool GetWindowRect(IntPtr window, out Rect rect);
    [DllImport("user32.dll")] private static extern bool PrintWindow(IntPtr window, IntPtr dc, uint flags);
    [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr window);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr window);
    [DllImport("user32.dll")] private static extern bool SetProcessDPIAware();

    public static Bitmap CaptureHeader(IntPtr window, int maxDimension) {
        SetProcessDPIAware();
        Rect rect;
        if (!GetWindowRect(window, out rect)) throw new InvalidOperationException("Window rectangle unavailable.");
        int width = Math.Min(3840, rect.Right - rect.Left);
        int height = Math.Min(350, (rect.Bottom - rect.Top) / 3);
        if (width < 250 || height < 55) throw new InvalidOperationException("Window is too small.");
        Bitmap image = new Bitmap(width, height, System.Drawing.Imaging.PixelFormat.Format32bppRgb);
        bool printed;
        using (Graphics g = Graphics.FromImage(image)) {
            IntPtr dc = g.GetHdc();
            try { printed = PrintWindow(window, dc, 2) || PrintWindow(window, dc, 0); }
            finally { g.ReleaseHdc(dc); }
        }
        if (printed) {
            if (width <= maxDimension) return image;
            Bitmap resized = new Bitmap(image, maxDimension, height * maxDimension / width);
            image.Dispose();
            return resized;
        }
        image.Dispose();
        throw new InvalidOperationException("Window cannot be captured.");
    }
}
'@

$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType=WindowsRuntime]
$null = [Windows.Media.Ocr.OcrResult, Windows.Foundation, ContentType=WindowsRuntime]
$null = [Windows.Globalization.Language, Windows.Foundation, ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Foundation, ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapPixelFormat, Windows.Foundation, ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapAlphaMode, Windows.Foundation, ContentType=WindowsRuntime]
$script:AwaitTask = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetParameters().Count -eq 1 -and
        $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
} | Select-Object -First 1

function Wait-WinRt($Operation, [type]$Type) {
    $task = $script:AwaitTask.MakeGenericMethod($Type).Invoke($null, @($Operation))
    if (!$task.Wait(2200)) { throw 'Windows OCR 超时。' }
    return $task.Result
}

function Read-HeaderCodes([IntPtr]$Window) {
    $language = [Windows.Globalization.Language]::new('zh-Hans')
    $ocr = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($language)
    if (!$ocr) { throw 'Windows 缺少简体中文光学字符识别语言包。' }
    $image = [StockWindow]::CaptureHeader($Window, [Windows.Media.Ocr.OcrEngine]::MaxImageDimension)
    $memory = [IO.MemoryStream]::new()
    try {
        $image.Save($memory, [Drawing.Imaging.ImageFormat]::Png)
        $memory.Position = 0
        $stream = [System.IO.WindowsRuntimeStreamExtensions]::AsRandomAccessStream($memory)
        try {
            $decoder = Wait-WinRt ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
            $pixels = Wait-WinRt ($decoder.GetSoftwareBitmapAsync([Windows.Graphics.Imaging.BitmapPixelFormat]::Bgra8, [Windows.Graphics.Imaging.BitmapAlphaMode]::Ignore)) ([Windows.Graphics.Imaging.SoftwareBitmap])
            try {
                $result = Wait-WinRt ($ocr.RecognizeAsync($pixels)) ([Windows.Media.Ocr.OcrResult])
                $candidates = foreach ($line in $result.Lines) {
                    Get-Codes $line.Text -RequireContext
                }
                return @($candidates | Sort-Object -Unique)
            } finally { $pixels.Dispose() }
        } finally { $stream.Dispose() }
    } finally { $memory.Dispose(); $image.Dispose() }
}

function Read-AccessibilityCodes([IntPtr]$Window) {
    $root = [System.Windows.Automation.AutomationElement]::FromHandle($Window)
    $walker = [System.Windows.Automation.TreeWalker]::ControlViewWalker
    $queue = [Collections.Generic.Queue[System.Windows.Automation.AutomationElement]]::new()
    $queue.Enqueue($root)
    $candidates = @()
    for ($visited = 0; $queue.Count -gt 0 -and $visited -lt 90; $visited++) {
        $node = $queue.Dequeue()
        try {
            $name = $node.Current.Name
            if ($name -match '^(?:证券代码|股票代码|品种代码|证券编号|股票编号)') {
                $candidates += @(Get-Codes $name)
                $pattern = $null
                if ($node.TryGetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern, [ref]$pattern)) {
                    $candidates += @(Get-Codes $pattern.Current.Value)
                }
            }
            for ($child = $walker.GetFirstChild($node); $child -and $queue.Count -lt 90; $child = $walker.GetNextSibling($child)) {
                $queue.Enqueue($child)
            }
        } catch [System.Windows.Automation.ElementNotAvailableException] {
            continue
        }
    }
    return @($candidates | Sort-Object -Unique)
}

function Read-ActiveStock([string]$App) {
    if ($App -eq 'tdx') {
        $name = '通达信'
        $processes = '^(?:tdxw(?:64)?|tdxmain(?:64)?|tdx(?:64)?)$'
    } else {
        $name = '同花顺'
        $processes = '^(?:hexin(?:64)?|ths(?:64)?)$'
    }
    $windows = @(Get-Process | Where-Object {
        $_.ProcessName -match $processes -and $_.MainWindowHandle -ne [IntPtr]::Zero -and
            [StockWindow]::IsWindowVisible($_.MainWindowHandle) -and ![StockWindow]::IsIconic($_.MainWindowHandle)
    })
    if ($windows.Count -eq 0) { return @{ error = "找不到 $name 的可见主窗口。请打开个股 K 线，保持客户端窗口未最小化。" } }
    if ($windows.Count -gt 1) { return @{ error = "检测到多个 $name 主窗口。请仅保留要联动的窗口可见。" } }
    $window = $windows[0]
    $found = @(Get-Codes $window.MainWindowTitle)
    if ($found.Count -eq 1) { return @{ code = $found[0]; method = '窗口标题' } }
    if ($found.Count -gt 1) { return @{ error = "$name 窗口标题出现多个股票代码，请切到单只股票的 K 线。" } }

    $accessibilityError = ''
    try { $found = @(Read-AccessibilityCodes $window.MainWindowHandle) }
    catch { $accessibilityError = $_.Exception.Message; $found = @() }
    if ($found.Count -eq 1) { return @{ code = $found[0]; method = '证券代码控件' } }
    if ($found.Count -gt 1) { return @{ error = "$name 窗口出现多个股票代码，请切到单只股票的 K 线。" } }
    try {
        $found = @(Read-HeaderCodes $window.MainWindowHandle)
    } catch {
        Write-Warning ("读取 {0} 窗口失败。UIA: {1}。OCR: {2}" -f $name, $accessibilityError, $_.Exception.Message)
        return @{ error = "$name 未提供可读取的代码。请保持单只股票 K 线可见并确认 Windows 简体中文 OCR 可用。" }
    }
    if ($found.Count -eq 1) { return @{ code = $found[0]; method = '窗口识别' } }
    return @{ error = "$name 窗口中没有识别出唯一股票代码。请切到单只股票的 K 线，确保顶部行情栏能看到代码。" }
}

function Write-Http($Stream, [int]$Status, [string]$Reason, [string]$Type, [byte[]]$Body) {
    $header = [Text.Encoding]::ASCII.GetBytes(
        "HTTP/1.1 $Status $Reason`r`nContent-Type: $Type`r`nContent-Length: $($Body.Length)`r`nConnection: close`r`nCache-Control: no-store`r`nX-Content-Type-Options: nosniff`r`n`r`n"
    )
    $Stream.Write($header, 0, $header.Length)
    $Stream.Write($Body, 0, $Body.Length)
}

function Write-Json($Stream, [int]$Status, [string]$Reason, $Result) {
    $bytes = [Text.Encoding]::UTF8.GetBytes(($Result | ConvertTo-Json -Compress))
    Write-Http $Stream $Status $Reason 'application/json; charset=utf-8' $bytes
}

function Receive-Http($Stream) {
    $head = [Collections.Generic.List[byte]]::new()
    while ($head.Count -lt 8192) {
        $byte = $Stream.ReadByte()
        if ($byte -lt 0) { return }
        $head.Add([byte]$byte)
        $length = $head.Count
        if ($length -ge 4 -and $head[$length-4] -eq 13 -and $head[$length-3] -eq 10 -and
            $head[$length-2] -eq 13 -and $head[$length-1] -eq 10) {
            return [Text.Encoding]::ASCII.GetString($head.ToArray())
        }
    }
    throw 'HTTP headers too large.'
}

$address = '127.0.0.1:17634'
$origin = 'http://' + $address
$page = [IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'market-workbench-preview.html'))
$listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, 17634)
$listener.Server.ExclusiveAddressUse = $true
$listener.Start()
try {
    Write-Host "本地联动已启动：$origin/。保持本窗口打开，Ctrl+C 可关闭。"
    if (!$NoOpen) { Start-Process ($origin + '/') }
    while ($true) {
        if (!$listener.Pending()) { Start-Sleep -Milliseconds 80; continue }
        $client = $listener.AcceptTcpClient()
        try {
            $client.ReceiveTimeout = 2200
            $client.SendTimeout = 2200
            $stream = $client.GetStream()
            $header = Receive-Http $stream
            if (!$header) { continue }
            $lines = $header -split "`r`n"
            $headers = @{}
            foreach ($line in $lines | Select-Object -Skip 1) {
                if ($line -match '^([^:]+):\s*(.*)$') { $headers[$Matches[1]] = $Matches[2].Trim() }
            }
            if ($headers['Host'] -cne $address) {
                Write-Json $stream 403 'Forbidden' @{ error = '仅允许本机访问。' }
            } elseif ($lines[0] -match '^GET / HTTP/1\.[01]$') {
                Write-Http $stream 200 'OK' 'text/html; charset=utf-8' $page
            } elseif ($lines[0] -match '^POST /api/stock-link/(tdx|ths) HTTP/1\.[01]$') {
                $app = $Matches[1]
                if ($headers['Origin'] -cne $origin -or $headers['X-Stock-Link'] -cne '1') {
                    Write-Json $stream 403 'Forbidden' @{ error = '请从本地工作台发起读取。' }
                } else {
                    $result = Read-ActiveStock $app
                    if ($result.ContainsKey('error')) { Write-Json $stream 422 'Unprocessable Entity' $result }
                    else { Write-Json $stream 200 'OK' $result }
                }
            } else {
                Write-Json $stream 404 'Not Found' @{ error = '地址不存在。' }
            }
        } catch {
            Write-Warning $_.Exception.Message
        } finally { $client.Dispose() }
    }
} finally { $listener.Stop() }
