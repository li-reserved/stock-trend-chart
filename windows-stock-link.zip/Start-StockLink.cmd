@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -STA -ExecutionPolicy RemoteSigned -File "%~dp0StockLink.ps1"
if errorlevel 1 pause
