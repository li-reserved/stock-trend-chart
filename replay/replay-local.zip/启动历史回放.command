#!/usr/bin/env python3
"""Serve the local HTML and read date-specific minute quotes from Tongdaxin."""
from datetime import date
from functools import lru_cache
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import json
import re
import socket
import struct
import subprocess
import sys
import threading
from urllib.parse import parse_qs, urlsplit
import zlib

ADDRESS = ("127.0.0.1", 8731)
APP = Path(__file__).resolve().with_name("盘口实验室.html")
QUOTE_HOST = ("124.71.187.122", 7709)
# Public Tongdaxin 7709 quote protocol; see github.com/rainx/pytdx and
# github.com/electkismet/eltdx (specified-date historical minute quotes, 0x0fb4).
HANDSHAKE = (
    "0c0218930001030003000d0001",
    "0c0218940001030003000d0002",
    "0c031899000120002000db0fd5d0c9ccd6a4a8af0000008fc22540130000d500c9ccbdf0d7ea00000002",
)
HISTORY = bytes.fromhex("0c01300001010d000d00b40f")
SYMBOL = re.compile(r"(?:sh60[0135]|sz00[0-3])[0-9]{3}\Z")


def read_exact(sock, size):
    result = bytearray()
    while len(result) < size:
        packet = sock.recv(size - len(result))
        if not packet:
            raise ConnectionError("行情主站中断连接")
        result.extend(packet)
    return result


def exchange(sock, request):
    sock.sendall(request)
    _, _, _, packed, plain = struct.unpack("<IIIHH", read_exact(sock, 16))
    body = read_exact(sock, packed)
    if packed != plain:
        body = zlib.decompress(body)
    if len(body) != plain:
        raise ValueError("行情包长度不符")
    return body


def signed_delta(values):
    first = next(values)
    magnitude = first & 63
    part, shift = first, 6
    while part & 128:
        part = next(values)
        magnitude |= (part & 127) << shift
        shift += 7
    return -magnitude if first & 64 else magnitude


@lru_cache(maxsize=384)
def minute_rows(code, trading_date):
    market = int(code.startswith("sh"))
    request = HISTORY + struct.pack("<IB6s", int(trading_date.replace("-", "")), market, code[2:].encode("ascii"))
    with socket.create_connection(QUOTE_HOST, timeout=5) as conn:
        for packet in HANDSHAKE:
            exchange(conn, bytes.fromhex(packet))
        body = exchange(conn, request)
    count, = struct.unpack_from("<H", body)
    if count != 240:
        return []
    values = iter(body[6:])
    rows, price = [], 0
    for _ in range(count):
        price += signed_delta(values)
        signed_delta(values)
        lots = signed_delta(values)
        if price <= 0 or lots < 0:
            raise ValueError("行情主站返回无效的分时量价")
        rows.append([price, lots * 100])
    return rows


class ReplayHandler(BaseHTTPRequestHandler):
    def send_body(self, status, body, kind):
        self.send_response(status)
        self.send_header("Content-Type", kind)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def send_json(self, status, value):
        self.send_body(status, json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                       "application/json; charset=utf-8")

    def do_GET(self):
        parts = urlsplit(self.path)
        if parts.path == "/":
            self.send_body(200, APP.read_bytes(), "text/html; charset=utf-8")
            return
        if parts.path != "/api/minutes":
            self.send_json(404, {"error": "路径不存在"})
            return
        args = parse_qs(parts.query)
        code = args.get("code", [""])[0]
        value = args.get("date", [""])[0]
        try:
            day = date.fromisoformat(value)
            if not SYMBOL.fullmatch(code) or day.isoformat() != value or day.year < 1990:
                raise ValueError
        except ValueError:
            self.send_json(400, {"error": "需要沪深主板代码与 YYYY-MM-DD 日期"})
            return
        try:
            rows = minute_rows(code, value)
        except (OSError, ValueError, struct.error, zlib.error, StopIteration) as exc:
            self.send_json(502, {"error": "通达信历史行情暂不可用：" + str(exc)})
            return
        self.send_json(200, {"date": value, "rows": rows})


if __name__ == "__main__":
    url = "http://127.0.0.1:8731/"
    if not APP.is_file():
        sys.exit("请把启动器和「盘口实验室.html」放在同一目录。")
    try:
        server = ThreadingHTTPServer(ADDRESS, ReplayHandler)
    except OSError as exc:
        sys.exit("启动失败：" + str(exc) + "。若已启动，请直接打开 " + url)
    with server:
        print("历史回放：" + url + "（关闭此窗口停止服务）", flush=True)
        if sys.platform == "darwin" and "--no-open" not in sys.argv:
            threading.Thread(target=subprocess.run, args=(["open", "-a", "Google Chrome", url],), daemon=True).start()
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
