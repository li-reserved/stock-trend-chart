/* Tongdaxin main-chart calculation. Input and output are chronological float arrays. */
#include <math.h>
#include <stdlib.h>

#define WINDOW 360
#define HISTORY 500
#define PIVOT_RADIUS 4
#define RANKED_UPPERS 12

typedef struct { double h, l, c, atr; } Bar;
typedef struct { int i; double value; } Pivot;
typedef struct { int i; double value, error; } Touch;
typedef struct { int valid, start, end, order; double m, b, score; } Line;
typedef struct { int valid, start, end, bottom, top; double score; } Box;
typedef struct {
    Bar bars[WINDOW];
    Pivot highs[WINDOW], lows[WINDOW];
    int n, high_count, low_count, gap, min_span;
    double close, atr;
} Study;

static double maxd(double a, double b) { return a > b ? a : b; }
static double mind(double a, double b) { return a < b ? a : b; }
static double value_at(Line line, int bar) { return line.b + line.m * bar; }
static double band_at(Bar bar, double price) {
    return maxd(0.01, maxd(0.007 * fabs(price), 0.54 * bar.atr));
}
static double cent(double value) { return round(value * 100.0) / 100.0; }

static int pivots(const Study *s, int from, int end, int high, Pivot *out) {
    int count = 0;
    for (int i = from + PIVOT_RADIUS; i < end - PIVOT_RADIUS; ++i) {
        const double value = high ? s->bars[i].h : s->bars[i].l;
        double left = 0.0, right = 0.0;
        int extreme = 1;
        for (int j = i - PIVOT_RADIUS; j <= i + PIVOT_RADIUS; ++j) {
            if (j == i) continue;
            const Bar bar = s->bars[j];
            const double candidate = high ? bar.h : bar.l;
            if ((high ? candidate > value : candidate < value) || (j < i && candidate == value)) {
                extreme = 0;
                break;
            }
            const double prominence = high ? value - bar.l : bar.h - value;
            if (j < i) left = maxd(left, prominence);
            else right = maxd(right, prominence);
        }
        if (extreme && mind(left, right) >= 0.8 * s->bars[i].atr) out[count++] = (Pivot){i, value};
    }
    return count;
}

static int contacts(const Study *s, const Pivot *points, int n, double m, double b, Touch *out) {
    int count = 0;
    for (int j = 0; j < n; ++j) {
        const Pivot point = points[j];
        const double error = fabs(point.value - (b + m * point.i)) / band_at(s->bars[point.i], point.value);
        if (error > 1.0) continue;
        const Touch touch = {point.i, point.value, error};
        if (count && point.i - out[count - 1].i < s->gap) {
            if (error < out[count - 1].error) out[count - 1] = touch;
        } else out[count++] = touch;
    }
    return count;
}

static Line assess(const Study *s, const Pivot *points, int n, double m, double b, int high, int min_span) {
    Touch hits[WINDOW];
    const int count = contacts(s, points, n, m, b, hits);
    if (count < 2 || hits[count - 1].i - hits[0].i < min_span) return (Line){0};
    const int start = hits[0].i, end = hits[count - 1].i, span = end - start;
    const double sign = high ? 1.0 : -1.0;
    int violations = 0, wick = 0;
    for (int i = start; i <= end; ++i) {
        const Bar bar = s->bars[i];
        const double y = b + m * i, band = band_at(bar, y);
        violations += sign * (bar.c - y) > band;
        wick += sign * ((high ? bar.h : bar.l) - y) > 1.7 * band;
    }
    if (violations > 0.12 * (span + 1) || wick > 0.20 * (span + 1)) return (Line){0};
    double fit = 0;
    for (int i = 0; i < count; ++i) fit += 1 - hits[i].error;
    const double distance = fabs(b + m * (s->n - 1) - s->close) / maxd(s->atr, 0.01);
    const double score = count * 2.1 + fit * 0.65 + (double)span / s->n * 8 + (double)end / s->n * 4
        - (violations * 2.0 + wick) / (span + 1) * 9 - mind(distance, 24) * 0.12;
    return (Line){1, start, end, 0, m, b, score};
}

static void slopes(const Study *s, int high, int direction, Line *ranked, int capacity) {
    const Pivot *points = high ? s->highs : s->lows;
    const int n = high ? s->high_count : s->low_count;
    for (int a = 0; a < n; ++a) {
        for (int z = a + 1; z < n; ++z) {
            const Pivot p = points[a], q = points[z];
            const int span = q.i - p.i;
            if (span < s->min_span || direction * (q.value - p.value) < 0.55 * (s->bars[p.i].atr + s->bars[q.i].atr)) continue;
            const double m = (q.value - p.value) / span, b = p.value - m * p.i;
            const Line line = assess(s, points, n, m, b, high, s->min_span);
            if (!line.valid) continue;
            for (int i = 0; i < capacity; ++i) {
                if (ranked[i].valid && line.score <= ranked[i].score) continue;
                for (int j = capacity - 1; j > i; --j) ranked[j] = ranked[j - 1];
                ranked[i] = line;
                break;
            }
        }
    }
}

static int compare_double(const void *a, const void *b) {
    const double x = *(const double *)a, y = *(const double *)b;
    return (x > y) - (x < y);
}

static int compare_line(const void *a, const void *b) {
    const Line x = *(const Line *)a, y = *(const Line *)b;
    if (x.score != y.score) return x.score > y.score ? -1 : 1;
    return x.order - y.order;
}

static int horizontal(const Study *s, int high, Line *ranked) {
    const Pivot *points = high ? s->highs : s->lows;
    const int n = high ? s->high_count : s->low_count;
    Touch hits[WINDOW];
    double prices[WINDOW];
    Line bands[WINDOW];
    int used = 0, output = 0;
    for (int i = 0; i < n; ++i) {
        int count = contacts(s, points, n, 0, points[i].value, hits);
        if (count < 2) continue;
        for (int j = 0; j < count; ++j) prices[j] = hits[j].value;
        qsort(prices, (size_t)count, sizeof(*prices), compare_double);
        const double b = cent((prices[(count - 1) / 2] + prices[count / 2]) / 2);
        count = contacts(s, points, n, 0, b, hits);
        if (count < 2) continue;
        const int start = hits[0].i, end = hits[count - 1].i;
        if (end - start < maxd(14, s->gap * 2)) continue;
        double fit = 0;
        for (int j = 0; j < count; ++j) fit += 1 - hits[j].error;
        const double score = count * 2.6 + (double)end / s->n * 4 + (double)(end - start) / s->n * 2
            + fit * 0.6 - mind(fabs(b - s->close) / maxd(s->atr, 0.01), 30) * 0.22;
        bands[used++] = (Line){1, start, end, i, 0, b, score};
    }
    qsort(bands, (size_t)used, sizeof(*bands), compare_line);
    for (int i = 0; i < used; ++i) {
        int distinct = 1;
        const double band = band_at(s->bars[s->n - 1], bands[i].b);
        for (int j = 0; j < output; ++j) {
            if (fabs(bands[i].b - ranked[j].b) <= band) { distinct = 0; break; }
        }
        if (distinct) ranked[output++] = bands[i];
    }
    return output;
}

static Box find_box(const Study *s, const Line *lows, int nl, const Line *highs, int nh) {
    Box best = {0};
    Touch low[WINDOW], high[WINDOW];
    int index[WINDOW * 2], side[WINDOW * 2];
    for (int a = 0; a < nl; ++a) {
        const int nlow = contacts(s, s->lows, s->low_count, 0, lows[a].b, low);
        for (int b = 0; b < nh; ++b) {
            if (highs[b].b - lows[a].b < maxd(2 * s->atr, s->close * 0.025)) continue;
            const int nhigh = contacts(s, s->highs, s->high_count, 0, highs[b].b, high);
            int p = 0, q = 0, count = 0;
            while (p < nlow || q < nhigh) {
                const int use_low = q == nhigh || (p < nlow && low[p].i <= high[q].i);
                side[count] = use_low;
                index[count++] = use_low ? low[p++].i : high[q++].i;
            }
            for (int j = 0; j < count - 3; ++j) {
                int alternations = 1;
                const int start = index[j];
                for (int k = j + 1; k < count; ++k) {
                    const int end = index[k];
                    alternations += side[k] != side[k - 1] && end > index[k - 1];
                    if (alternations < 4 || end - start < maxd(23, s->gap * 2)) continue;
                    const double score = alternations * 1.1 + (double)end / s->n * 7 + (double)(end - start) / s->n * 2
                        - mind(fabs(lows[a].b - s->close) / maxd(s->atr, 0.01), 25) * 0.16;
                    if (best.valid && score <= best.score) continue;
                    int outside = 0, streak = 0, longest = 0;
                    for (int i = start; i <= end; ++i) {
                        const Bar bar = s->bars[i];
                        if (bar.c < lows[a].b - band_at(bar, lows[a].b) || bar.c > highs[b].b + band_at(bar, highs[b].b)) {
                            ++outside;
                            if (++streak > longest) longest = streak;
                        } else streak = 0;
                    }
                    if (outside <= 0.15 * (end - start + 1) && longest < 6) best = (Box){1, start, end, a, b, score};
                }
            }
        }
    }
    return best;
}

static int load_study(Study *s, int count, const float *high, const float *low, const float *close) {
    const int start = count > WINDOW ? count - WINDOW : 0;
    const int warmup = count > HISTORY ? count - HISTORY : 0;
    s->n = count - start;
    double atr = 0;
    for (int i = warmup; i < count; ++i) {
        const double h = high[i], l = low[i], c = close[i], prior = i == warmup ? c : close[i - 1];
        if (!isfinite(h) || !isfinite(l) || !isfinite(c) || h < l || c < l - 0.0001 || c > h + 0.0001) return 0;
        const double tr = i == warmup ? h - l : maxd(h - l, maxd(fabs(h - prior), fabs(l - prior)));
        const double span = mind(i - warmup + 1, 14);
        atr = (atr * (span - 1) + tr) / span;
        if (i >= start) s->bars[i - start] = (Bar){h, l, c, atr};
    }
    s->close = close[count - 1];
    s->atr = atr;
    s->gap = (int)maxd(7, floor(s->n * 0.027));
    s->min_span = (int)maxd(23, round(s->n * 0.16));
    s->high_count = pivots(s, 0, s->n, 1, s->highs);
    s->low_count = pivots(s, 0, s->n, 0, s->lows);
    return s->close > 0;
}

static void write_line(float *last, int id, Line line, int end) {
    if (!line.valid) return;
    const int slot = 1 + id * 4;
    last[-slot] = (float)value_at(line, end);
    last[-(slot + 1)] = (float)line.m;
    last[-(slot + 2)] = (float)(end - line.start);
    last[-(slot + 3)] = (float)(end - line.end);
}

static void calculate(int count, float *out, float *high, float *low, float *close) {
    if (count <= 0 || !out) return;
    for (int i = 0; i < count; ++i) out[i] = 0;
    if (count < 60 || !high || !low || !close) return;
    Study s;
    if (!load_study(&s, count, high, low, close)) return;
    const int end = s.n - 1;
    float *last = &out[count - 1];
    last[0] = 4101;

    Line upper[RANKED_UPPERS] = {{0}}, lines[4] = {{0}};
    slopes(&s, 1, -1, upper, RANKED_UPPERS);
    lines[0] = upper[0];
    for (int i = 0; i < RANKED_UPPERS && upper[i].valid && upper[i].score >= upper[0].score * 0.85; ++i) {
        const Line line = upper[i];
        int first = 0;
        while (first < s.low_count && s.lows[first].i < line.start) ++first;
        Line lower = {0};
        for (int j = first; j < s.low_count; ++j) {
            const Pivot pivot = s.lows[j];
            const double b = pivot.value - line.m * pivot.i;
            if (line.b - b < 1.5 * s.bars[pivot.i].atr) continue;
            const Line fit = assess(&s, &s.lows[first], s.low_count - first, line.m, b, 0, (int)maxd(20, round(s.min_span * 0.75)));
            if (fit.valid && mind(fit.end, line.end) - maxd(fit.start, line.start) >= maxd(14, s.min_span * 0.4)
                && (!lower.valid || fit.score > lower.score)) lower = fit;
        }
        if (lower.valid) { lines[0] = line; lines[1] = lower; break; }
    }
    slopes(&s, 0, 1, &lines[2], 1);
    Line lows[WINDOW], highs[WINDOW];
    const int nl = horizontal(&s, 0, lows), nh = horizontal(&s, 1, highs);
    int key = -1, pressure = -1;
    for (int i = 0; i < nl && key < 0; ++i) if (lows[i].b <= s.close) key = i;
    for (int i = 0; i < nh && pressure < 0; ++i) if (highs[i].b >= s.close) pressure = i;
    if (key < 0 && nl) key = 0;
    if (pressure < 0 && nh) pressure = 0;
    if (key >= 0) lines[3] = lows[key];
    const Box box = find_box(&s, lows, nl, highs, nh);
    int floor_index = -1, fallback_floor = -1;
    for (int i = 0; i < nl; ++i) {
        if (i == key || lows[i].b > s.close) continue;
        if (fallback_floor < 0 || lows[i].b > lows[fallback_floor].b) fallback_floor = i;
        if (box.valid && i == box.bottom) continue;
        if (floor_index < 0 || lows[i].b > lows[floor_index].b) floor_index = i;
    }
    if (floor_index < 0) floor_index = fallback_floor;
    for (int i = 0; i < 4; ++i) write_line(last, i, lines[i], end);
    if (box.valid) {
        last[-17] = (float)lows[box.bottom].b;
        last[-18] = (float)highs[box.top].b;
        last[-19] = (float)(end - box.start);
    }
    if (floor_index >= 0) {
        last[-20] = (float)lows[floor_index].b;
        last[-21] = (float)(end - lows[floor_index].start);
    }
    if (pressure >= 0) {
        last[-22] = (float)highs[pressure].b;
        last[-23] = (float)(end - highs[pressure].start);
    }

    double support = 0, resistance = 0, next_support = 0, next_resistance = 0;
    double below[WINDOW + 6], above[WINDOW + 4];
    int nb = 0, na = 0;
    for (int i = 0; i < 4; ++i) {
        if (!lines[i].valid) continue;
        const double y = cent(value_at(lines[i], end));
        if (i == 0 && y >= s.close) above[na++] = y;
        if (i != 0 && y > 0 && y <= s.close) below[nb++] = y;
    }
    if (box.valid && lows[box.bottom].b <= s.close) below[nb++] = lows[box.bottom].b;
    if (box.valid && highs[box.top].b >= s.close) above[na++] = highs[box.top].b;
    if (floor_index >= 0) below[nb++] = lows[floor_index].b;
    if (pressure >= 0 && highs[pressure].b >= s.close) above[na++] = highs[pressure].b;
    for (int i = 0; i < nb; ++i) support = maxd(support, below[i]);
    for (int i = 0; i < na; ++i) if (resistance == 0 || above[i] < resistance) resistance = above[i];
    for (int i = 0; i < nl; ++i) if (lows[i].b <= s.close) below[nb++] = lows[i].b;
    for (int i = 0; i < nh; ++i) if (highs[i].b >= s.close) above[na++] = highs[i].b;
    const double threshold = band_at(s.bars[end], s.close);
    for (int i = 0; i < nb; ++i) if (below[i] > 0 && support - below[i] > threshold) next_support = maxd(next_support, below[i]);
    for (int i = 0; i < na; ++i) if (resistance > 0 && above[i] - resistance > threshold &&
        (!next_resistance || above[i] < next_resistance)) next_resistance = above[i];
    last[-24] = (float)support;
    last[-25] = (float)next_support;
    last[-26] = (float)resistance;
    last[-27] = (float)next_resistance;
    const int inside = box.valid && s.close >= lows[box.bottom].b && s.close <= highs[box.top].b;
    const double range_low = inside ? lows[box.bottom].b : support;
    const double range_high = inside ? highs[box.top].b : resistance;
    if (range_low > 0 && range_high - range_low >= maxd(maxd(fabs(s.close) * 0.003, s.atr * 0.25), 0.01)) {
        last[-28] = (float)range_low;
        last[-29] = (float)range_high;
    }

    int slot = 30;
    for (int i = 0; i < 4; ++i) {
        for (int j = i + 1; j < 4; ++j, slot += 2) {
            const Line a = lines[i], b = lines[j];
            if (!a.valid || !b.valid || fabs(a.m - b.m) < 1e-9) continue;
            const double x = (b.b - a.b) / (a.m - b.m);
            const double y = a.b + a.m * x;
            if (x >= maxd(a.start, b.start) && x - end < 10000 && y > 0) {
                last[-slot] = (float)(x - end);
                last[-(slot + 1)] = (float)y;
            }
        }
    }

    Pivot confirmed_lows[WINDOW], confirmed_highs[WINDOW];
    const int from = (int)maxd(0, s.n - 61);
    int il = pivots(&s, from, end, 0, confirmed_lows) - 1;
    int ih = pivots(&s, from, end, 1, confirmed_highs) - 1;
    if (il >= 0 && ih >= 0 && confirmed_highs[ih].value <= confirmed_lows[il].value) {
        if (confirmed_highs[ih].i > confirmed_lows[il].i) {
            while (il >= 0 && confirmed_lows[il].value >= confirmed_highs[ih].value) --il;
        } else {
            while (ih >= 0 && confirmed_highs[ih].value <= confirmed_lows[il].value) --ih;
        }
    }
    if (il >= 0) last[-42] = (float)confirmed_lows[il].value;
    if (ih >= 0) last[-43] = (float)confirmed_highs[ih].value;
}

typedef void (*TdxFunction)(int, float *, float *, float *, float *);
#ifdef _WIN32
#pragma pack(push, 1)
#endif
typedef struct { unsigned short number; TdxFunction function; } TdxExport;
#ifdef _WIN32
#pragma pack(pop)
#endif
static TdxExport exports[] = {{1, calculate}, {0, 0}};

#ifdef _WIN32
__declspec(dllexport)
#endif
int RegisterTdxFunc(TdxExport **output) {
    if (!output || *output) return 0;
    *output = exports;
    return 1;
}
